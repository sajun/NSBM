-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2018 at 03:29 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nsbm`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `CourseId` varchar(25) NOT NULL,
  `CourseName` varchar(150) NOT NULL,
  `Years` int(4) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `TotalCredits` int(2) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`CourseId`, `CourseName`, `Years`, `Type`, `TotalCredits`, `FacId`) VALUES
('SC01', 'Bsc in Computer Science', 3, '3-Year Bachelor', 30, '001'),
('SC02', 'Bachelor of Information Technology', 3, '3-Year Bachelor', 30, '001'),
('SC03', 'BSc (Honours) in Software Engineering', 4, '4-Year Bachelor', 32, '001'),
('SC04', 'Msc in Computer Science', 2, 'Master', 24, '001');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `FacId` varchar(25) NOT NULL,
  `FacName` varchar(50) NOT NULL,
  `PrgNo` int(11) NOT NULL,
  `Semester` int(2) NOT NULL,
  `IsOpen` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`FacId`, `FacName`, `PrgNo`, `Semester`, `IsOpen`) VALUES
('001', 'School of Computing', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hall`
--

CREATE TABLE `hall` (
  `HallId` varchar(25) NOT NULL,
  `Capacity` int(11) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hall`
--

INSERT INTO `hall` (`HallId`, `Capacity`, `Location`, `FacId`) VALUES
('H001', 10, 'abc', '001');

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `InstructorId` varchar(25) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Qualification` mediumtext NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`InstructorId`, `Name`, `Qualification`, `FacId`) VALUES
('E001', 'E1', 'Q1, Q2, Q3', '001');

-- --------------------------------------------------------

--
-- Table structure for table `lab`
--

CREATE TABLE `lab` (
  `LabId` varchar(25) NOT NULL,
  `LabName` varchar(100) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lab`
--

INSERT INTO `lab` (`LabId`, `LabName`, `FacId`) VALUES
('LB001', 'lab1', '001');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `LecturerId` varchar(25) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Qualification` mediumtext NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`LecturerId`, `Name`, `Qualification`, `FacId`) VALUES
('L001', 'L1', 'L1', '001');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `StdId` varchar(25) NOT NULL,
  `SubId` varchar(25) NOT NULL,
  `IsPaid` int(2) NOT NULL,
  `Semester` int(2) NOT NULL,
  `Amount` int(5) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `std_postgrad`
--

CREATE TABLE `std_postgrad` (
  `StdId` varchar(25) NOT NULL,
  `QualificationType` varchar(150) NOT NULL,
  `Institute` varchar(150) NOT NULL,
  `Year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `std_postgrad`
--

INSERT INTO `std_postgrad` (`StdId`, `QualificationType`, `Institute`, `Year`) VALUES
('STP001', '001', '001', 1);

-- --------------------------------------------------------

--
-- Table structure for table `std_sub`
--

CREATE TABLE `std_sub` (
  `StdId` varchar(25) NOT NULL,
  `SubId` varchar(25) NOT NULL,
  `Year` int(5) NOT NULL,
  `Semester` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `std_sub`
--

INSERT INTO `std_sub` (`StdId`, `SubId`, `Year`, `Semester`) VALUES
('STD002', 'SUB09', 2, 1),
('STD002', 'SUB10', 2, 2),
('STD002', 'SUB11', 2, 1),
('STD002', 'SUB13', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `std_undergrad`
--

CREATE TABLE `std_undergrad` (
  `StdId` varchar(25) NOT NULL,
  `AL_index` varchar(15) NOT NULL,
  `ResultSub1` varchar(3) NOT NULL,
  `ResultSub2` varchar(3) NOT NULL,
  `ResultSub3` varchar(3) NOT NULL,
  `ResultSub4` varchar(3) NOT NULL,
  `IslandRank` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `std_undergrad`
--

INSERT INTO `std_undergrad` (`StdId`, `AL_index`, `ResultSub1`, `ResultSub2`, `ResultSub3`, `ResultSub4`, `IslandRank`) VALUES
('STD001', '001', '001', '001', '001', '001', 1),
('STD002', '002', '002', '002', '002', '002', 2);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `StdId` varchar(25) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `CourseId` varchar(25) NOT NULL,
  `CurrentYear` int(5) NOT NULL,
  `RegDate` varchar(15) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`StdId`, `Name`, `Address`, `DOB`, `CourseId`, `CurrentYear`, `RegDate`, `FacId`) VALUES
('STD001', '001', '001', '001', 'SC03', 4, '12/08/2018', '001'),
('STD002', '002', '002', '002', 'SC01', 2, '12/08/2018', '001'),
('STP001', '001', '001', '001', 'SC04', 2, '12/08/2018', '001');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `SubId` varchar(25) NOT NULL,
  `SubName` varchar(150) NOT NULL,
  `IsPracticle` int(2) NOT NULL,
  `IsTheory` int(2) NOT NULL,
  `IsOptional` int(2) NOT NULL,
  `Credits` int(4) NOT NULL,
  `Price` int(11) NOT NULL,
  `CourseId` varchar(25) NOT NULL,
  `Year` int(2) NOT NULL,
  `Semester` int(2) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`SubId`, `SubName`, `IsPracticle`, `IsTheory`, `IsOptional`, `Credits`, `Price`, `CourseId`, `Year`, `Semester`, `FacId`) VALUES
('SUB01', 'COMP1', 1, 1, 0, 5, 2500, 'SC01', 1, 1, '001'),
('SUB02', 'COMP2', 1, 1, 0, 5, 3000, 'SC01', 1, 1, '001'),
('SUB03', 'COMP3', 1, 1, 0, 3, 2000, 'SC01', 1, 2, '001'),
('SUB04', 'OPT4', 1, 1, 1, 2, 3000, 'SC01', 1, 2, '001'),
('SUB05', 'OPT1', 0, 1, 1, 5, 2500, 'SC01', 1, 1, '001'),
('SUB06', 'OPT2', 1, 1, 1, 5, 2500, 'SC01', 1, 1, '001'),
('SUB07', 'OPT3', 1, 0, 1, 2, 2000, 'SC01', 1, 2, '001'),
('SUB08', 'COMP4', 0, 1, 0, 3, 2500, 'SC01', 1, 2, '001'),
('SUB09', 'COMP5', 1, 1, 0, 10, 1111, 'SC01', 2, 1, '001'),
('SUB10', 'COMP6', 1, 0, 0, 10, 1111, 'SC01', 2, 2, '001'),
('SUB11', 'OPT05', 0, 0, 1, 5, 2222, 'SC01', 2, 1, '001'),
('SUB12', 'OPT6', 0, 1, 1, 5, 1234, 'SC01', 2, 2, '001'),
('SUB13', 'OPT7', 0, 1, 1, 5, 1000, 'SC01', 2, 2, '001');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserId` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `IsAdmin` int(11) NOT NULL,
  `IsStdMan` int(11) NOT NULL,
  `IsExamMan` int(11) NOT NULL,
  `FacId` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserId`, `Username`, `Password`, `IsAdmin`, `IsStdMan`, `IsExamMan`, `FacId`) VALUES
(4, '4', 'a87ff679a2f3e71d9181a67b7542122c', 1, 1, 1, '001'),
(5, '5', 'e4da3b7fbbce2345d7772b0674a318d5', 1, 1, 1, '001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`CourseId`),
  ADD KEY `FacId` (`FacId`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`FacId`);

--
-- Indexes for table `hall`
--
ALTER TABLE `hall`
  ADD PRIMARY KEY (`HallId`),
  ADD KEY `FacId` (`FacId`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`InstructorId`),
  ADD KEY `FacId` (`FacId`);

--
-- Indexes for table `lab`
--
ALTER TABLE `lab`
  ADD PRIMARY KEY (`LabId`),
  ADD KEY `FacId` (`FacId`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`LecturerId`),
  ADD KEY `FacId` (`FacId`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`StdId`,`SubId`);

--
-- Indexes for table `std_postgrad`
--
ALTER TABLE `std_postgrad`
  ADD PRIMARY KEY (`StdId`);

--
-- Indexes for table `std_sub`
--
ALTER TABLE `std_sub`
  ADD PRIMARY KEY (`StdId`,`SubId`),
  ADD KEY `SubId` (`SubId`);

--
-- Indexes for table `std_undergrad`
--
ALTER TABLE `std_undergrad`
  ADD PRIMARY KEY (`StdId`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`StdId`),
  ADD KEY `FacId` (`FacId`),
  ADD KEY `CourseId` (`CourseId`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`SubId`),
  ADD KEY `FacId` (`FacId`),
  ADD KEY `CourseId` (`CourseId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserId`),
  ADD KEY `FacId` (`FacId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE;

--
-- Constraints for table `hall`
--
ALTER TABLE `hall`
  ADD CONSTRAINT `hall_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE;

--
-- Constraints for table `instructor`
--
ALTER TABLE `instructor`
  ADD CONSTRAINT `instructor_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE;

--
-- Constraints for table `lab`
--
ALTER TABLE `lab`
  ADD CONSTRAINT `lab_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE;

--
-- Constraints for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD CONSTRAINT `lecturer_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE;

--
-- Constraints for table `std_postgrad`
--
ALTER TABLE `std_postgrad`
  ADD CONSTRAINT `std_postgrad_ibfk_1` FOREIGN KEY (`StdId`) REFERENCES `student` (`StdId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `std_sub`
--
ALTER TABLE `std_sub`
  ADD CONSTRAINT `std_sub_ibfk_1` FOREIGN KEY (`SubId`) REFERENCES `subject` (`SubId`) ON UPDATE CASCADE,
  ADD CONSTRAINT `std_sub_ibfk_2` FOREIGN KEY (`StdId`) REFERENCES `student` (`StdId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `std_undergrad`
--
ALTER TABLE `std_undergrad`
  ADD CONSTRAINT `std_undergrad_ibfk_1` FOREIGN KEY (`StdId`) REFERENCES `student` (`StdId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`CourseId`) REFERENCES `course` (`CourseId`) ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_ibfk_2` FOREIGN KEY (`CourseId`) REFERENCES `course` (`CourseId`) ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`FacId`) REFERENCES `faculty` (`FacId`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
