import java.sql.*;
import java.util.*;

import javax.swing.JOptionPane;

public class Admin {

	public void login() {
		AdminDash.main(null);
	}
}
