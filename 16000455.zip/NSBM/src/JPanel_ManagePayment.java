import javax.swing.JPanel;

public class JPanel_ManagePayment extends JPanel {

	/**
	 * Create the panel.
	 */
	public JPanel_ManagePayment() {
		setLayout(null);

	}

}
