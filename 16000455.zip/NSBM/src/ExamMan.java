import java.sql.*;
import java.util.*;

import javax.swing.JOptionPane;

public class ExamMan {
	public void login() {
		ExamManDash.main(null);
	}
}
